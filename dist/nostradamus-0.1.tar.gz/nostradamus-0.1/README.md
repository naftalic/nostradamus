# Nostradamus

A time-series forecasting python package.

## Usage

...

```
...
```
