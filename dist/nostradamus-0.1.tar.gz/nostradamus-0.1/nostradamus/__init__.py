# Copyright (c) 2020-present, Naftali Cohen
# All rights reserved.

from nostradamus.forecaster import Nostradamus

__version__ = '0.1'
