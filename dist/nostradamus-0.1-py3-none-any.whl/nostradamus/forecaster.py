#

import numpy as np
import pandas as pd


class Nostradamus(object):

    def __init__(self):
        print('hello!')
