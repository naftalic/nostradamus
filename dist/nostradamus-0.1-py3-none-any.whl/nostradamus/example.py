#

import sys
import numpy as np
import pandas as pd

sys.path.append('/Users/naftali/')  # path to nostradamus library
from nostradamus.forecaster import Nostradamus

Nostradamus()
